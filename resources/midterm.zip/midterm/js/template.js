
skel.init(
    {
        prefix: 'css/template',
        preloadStyleSheets: true,
        normalizeCSS: true,
        boxModel: 'border',
        grid: { gutters: 20 },
        breakpoints: {
            wide: { hasStyleSheet: false, range: '961-', containers: 960 },
            narrow: { hasStyleSheet: false, range: '481-960', containers: 680 },
            mobile: { hasStyleSheet: false, range: '-480', containers: 'fluid', lockViewport: true, grid: { collapse: true } }
        }
    }
);
