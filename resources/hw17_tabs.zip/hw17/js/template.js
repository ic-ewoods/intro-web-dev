
skel.init(
    {
        prefix: 'css/template',
        preloadStyleSheets: true,
        normalizeCSS: true,
        boxModel: 'border',
        grid: { gutters: 20 },
        breakpoints: {
            wide: { hasStyleSheet: false, range: '1200-', containers: 1140, grid: { gutters: 40 } },
            narrow: { hasStyleSheet: false, range: '481-1199', containers: 960 },
            mobile: { hasStyleSheet: false, range: '-480', containers: 320, lockViewport: true, grid: { collapse: true } }
        }
    }
);
